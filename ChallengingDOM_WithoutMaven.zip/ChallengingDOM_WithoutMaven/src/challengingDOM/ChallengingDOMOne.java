package challengingDOM;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;

//This test finds the various button fields in AUT
public class ChallengingDOMOne {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/challenging_dom");
		
		//To launch chrome in full window
		driver.manage().window().maximize();
		
		String a,b,c;
		
		//Getting text of button #1
		WebElement btn1 = driver.findElement(By.className("button"));
		a= btn1.getText();
		System.out.println("The text of bar button is :" +a);
		
		//Getting text of button #2
		WebElement btn2 = driver.findElement(By.className("button alert"));
		b= btn2.getText();
		System.out.println("The text of bar button is :" +b);
		
		//Getting text of button
		WebElement btn3 = driver.findElement(By.className("button success"));
		c= btn3.getText();
		System.out.println("The text of bar button is :" +c);

		driver.quit();
	}

}

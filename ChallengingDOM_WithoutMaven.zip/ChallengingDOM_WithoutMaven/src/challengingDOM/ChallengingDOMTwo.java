package challengingDOM;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;

//This test finds the various link fields in AUT
public class ChallengingDOMTwo {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/challenging_dom");
		
		//To launch chrome in full window
		driver.manage().window().maximize();
		
		String a,b;
		
		//Getting text of link #1
		WebElement lnk1 = driver.findElement(By.linkText("edit"));
		a= lnk1.getText();
		System.out.println("The text of Link #1 is :" +a);
		
		//Getting text of link #2
		WebElement lnk2 = driver.findElement(By.linkText("delete"));
		b= lnk2.getText();
		System.out.println("The text of Link #2 is :" +b);
		

		driver.quit();
	}

}

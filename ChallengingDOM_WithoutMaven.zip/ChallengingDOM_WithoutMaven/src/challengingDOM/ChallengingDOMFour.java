package challengingDOM;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;

//This test finds the header field present in the table
public class ChallengingDOMFour {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/challenging_dom");
		
		//To launch chrome in full window
		driver.manage().window().maximize();
		
				
		//Getting text of column #1
		WebElement lnk1 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/thead/tr/th[1]"));			
		System.out.println("The name of column #1 is : " +lnk1.getText());
		
		//Getting text of column #2
		WebElement lnk2 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/thead/tr/th[2]"));			
		System.out.println("The name of column #2 is : " +lnk2.getText());
		
		//Getting text of column #1
		WebElement lnk3 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/thead/tr/th[3]"));			
		System.out.println("The name of column #3 is : " +lnk3.getText());
		
		//Getting text of column #4
		WebElement lnk4 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/thead/tr/th[4]"));			
		System.out.println("The name of column #4 is : " +lnk4.getText());
		
		//Getting text of column #5
		WebElement lnk5 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/thead/tr/th[5]"));			
		System.out.println("The name of column #5 is: " +lnk5.getText());
		
		//Getting text of column #6
		WebElement lnk6 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/thead/tr/th[6]"));			
		System.out.println("The name of column #6 is : " +lnk6.getText());
		
		//Getting text of column #7
		WebElement lnk7 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/thead/tr/th[7]"));			
		System.out.println("The name of column #7 is : " +lnk7.getText());
		
	
		

		driver.quit();
	}

}

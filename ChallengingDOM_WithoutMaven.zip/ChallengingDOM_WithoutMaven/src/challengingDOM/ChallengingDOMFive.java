package challengingDOM;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;

//This test displays the values of Row #1 present in the table
public class ChallengingDOMFive {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/challenging_dom");
		
		//To launch chrome in full window
		driver.manage().window().maximize();
		
				
		//Getting text of Row #1, column #1
		WebElement lnk1 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/tbody/tr[1]/td[1]"));		
		System.out.println("The name of Row #1,column #1 is : " +lnk1.getText());
		
		//Getting text of Row #1, column #2
		WebElement lnk2 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/tbody/tr[1]/td[2]"));			
		System.out.println("The name of Row #1,column #2 is : " +lnk2.getText());
		
		//Getting text of Row #1, column #3
		WebElement lnk3 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/tbody/tr[1]/td[3]"));			
		System.out.println("The name of Row #1,column #3 is : " +lnk3.getText());
		
		//Getting text of Row #1, column #4
		WebElement lnk4 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/tbody/tr[1]/td[4]"));			
		System.out.println("The name of Row #1,column #4 is : " +lnk4.getText());
		
		//Getting text of Row #1, column #5
		WebElement lnk5 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/tbody/tr[1]/td[5]"));			
		System.out.println("The name of Row #1,column #5 is: " +lnk5.getText());
		
		//Getting text ofRow #1,  column #6
		WebElement lnk6 = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]/table/tbody/tr[1]/td[6]"));			
		System.out.println("The name of Row #1,column #6 is : " +lnk6.getText());
				

		driver.quit();
	}

}

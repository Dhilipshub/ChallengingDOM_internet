package challengingDOM;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;

//This test finds the canvas field present in AUT
public class ChallengingDOMThree {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/challenging_dom");
		
		//To launch chrome in full window
		driver.manage().window().maximize();
		
				
		//Getting text of canvas
		WebElement lnk1 = driver.findElement(By.xpath("//table[@id='canvas']/tbody/div/"));			
		System.out.println("The text of canvas is :" +lnk1.getText());
		
	
		

		//driver.quit();
	}

}

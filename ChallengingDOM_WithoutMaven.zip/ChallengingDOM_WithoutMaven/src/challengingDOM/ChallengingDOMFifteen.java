package challengingDOM;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//This test displays the canvas value after clicking the various buttons present in the table
public class ChallengingDOMFifteen {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/challenging_dom");
		
		//To launch chrome in full window
		driver.manage().window().maximize();
		
		//Button #1
		WebElement btn1 = driver.findElement(By.className("button"));
		btn1.click();	
		WebElement waitBtn1 = (new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.className("button")));		
		
		//Getting text of canvas after clicking Button #1
		WebElement lnk1 = driver.findElement(By.xpath("//table[@id='canvas']/tbody/div/"));			
		System.out.println("The text of canvas after clicking Button #1 is :" +lnk1.getText());

		//Getting text of button #2
		WebElement btn2 = driver.findElement(By.className("button alert"));
		btn2.click();	
		WebElement waitBtn2 = (new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.className("button alert")));
		
		
		//Getting text of canvas after clicking Button #1
		WebElement lnk2 = driver.findElement(By.xpath("//table[@id='canvas']/tbody/div/"));			
		System.out.println("The text of canvas after clicking Button #2 is :" +lnk2.getText());

		//Getting text of button
		WebElement btn3 = driver.findElement(By.className("button success"));
		btn3.click();
		WebElement waitBtn3 = (new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.className("button success")));
				
		//Getting text of canvas after clicking Button #1
		WebElement lnk3 = driver.findElement(By.xpath("//table[@id='canvas']/tbody/div/"));			
		System.out.println("The text of canvas after clicking Button #3 is :" +lnk3.getText());
		
					

		driver.quit();
	}

}
